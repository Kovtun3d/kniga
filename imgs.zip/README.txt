ATTENTION!!!

In the application, you need to select a book, open the selected book (in your case, the corresponding archive with page images), then point to the page with the mark and observe the content in augmented reality